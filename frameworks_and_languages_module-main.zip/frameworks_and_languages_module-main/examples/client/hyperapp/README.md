
* [Hyperapp](https://github.com/jorgebucaran/hyperapp#hyperapp) - The tiny framework for building hypertext applications.
    * Important concept - all html is build with js functions in the form
        * [h(tag, props, children)](https://github.com/jorgebucaran/hyperapp/blob/main/docs/api/h.md#h)
        * [@hyperapp/html](https://github.com/jorgebucaran/hyperapp/tree/main/packages/html)