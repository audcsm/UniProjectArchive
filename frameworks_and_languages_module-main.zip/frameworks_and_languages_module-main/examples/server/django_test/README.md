Django
======

* https://gitpod.io/#https://github.com/gitpod-io/template-python-django
    * Turn off autosave in vscode - why does this feature exist!?

* https://www.djangoproject.com/
* Tutorial
    * https://docs.djangoproject.com/en/3.2/intro/tutorial01/
    * https://docs.djangoproject.com/en/3.2/intro/tutorial02/
    * https://docs.djangoproject.com/en/3.2/intro/tutorial03/
