# dotnet_docker_test
Example WeatherApp running in docker containers

```bash
make build
make run
# http://localhost:5000/WeatherForecast
```

Tutorial
https://docs.microsoft.com/en-us/aspnet/core/tutorials/first-web-api?view=aspnetcore-5.0&tabs=visual-studio-code

https://code.visualstudio.com/docs/containers/quickstart-aspnet-core
https://devblogs.microsoft.com/premier-developer/running-a-net-core-web-application-in-docker-container-using-docker-desktop-for-windows/
https://docs.microsoft.com/en-us/aspnet/core/tutorials/first-web-api?view=aspnetcore-5.0&tabs=visual-studio-code