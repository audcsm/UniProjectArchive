Laravel
=======

* https://laravel.com/
    * Look at the echo system
* https://laravel.com/docs/8.x#getting-started-on-linux
* curl -s https://laravel.build/example-app | bash
* cd example-app 
* ./vendor/bin/sail up
    * downloads mysql, redis, mailhog, selenium + chrome, ubuntu
* http://localhost
    * This didnt work - after downloading 4gb+ of dependencies
* docker-compose down
* https://laravel.com/docs/8.x#laravel-the-api-backend
    * looks like it can be used as an API backend ... but this seems like a sledgehammer to crack a nut
    * https://laravel.com/docs/8.x/responses#strings-arrays
