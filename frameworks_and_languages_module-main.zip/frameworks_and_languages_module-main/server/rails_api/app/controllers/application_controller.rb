class ApplicationController < ActionController::API
#  rescue_from ActiveRecord::BadParams, with: :not_saved

#  private
#  def not_saved(invalid)
#    render json: {errors: invalid.record.errors}, status: :method_not_allowed
#  end
end
